global.option = {
    owner: ['6283818744065','62895613293360'],
    nameBot: `N D Y I E`,
    database: 'database.json'
}

global.exif = {
    web: 'https://xnxx.com',
    stickerName: 'rendy gamtenx',
    stickerDescription: 'this bot using baileys!',
    email: 'rendynoviansyah@gmail.com',
    packname: 'kanjut',
    author: 'rendy'
}

global.emoji = {
    loading: '⏳',
    done: '✅',
    gagal: '❌'
}