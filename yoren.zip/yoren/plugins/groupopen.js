let cmd = ['tutupgroup', 'bukagroup']
export default {
    cmd: cmd,
    tags: ['admin'],
    help: cmd,
    group: true,
    botAdmin: true,
    admin: true,
    exec: async function(m, conn, {cmd}) {
           switch (cmd) {
                case 'tutupgroup' : {
                    m.reply('admin mengubah hanya admin yang boleh mengirim pesan')
                    await conn.     groupSettingUpdate(m.chat, 'announcement')
                }
                break
                case 'bukagroup' : {
                    m.reply('group di atur untuk semua orang')
                    await conn.groupSettingUpdate(m.chat, 'not_announcement')
                }
                break
           }
    }
}

