export default {
handler.command = ['gantibio'];
handler.execute = async (m, { conn, args, text }) => {
  if (args.length < 1) return m.reply('Masukkan bio baru!');
  const bioBaru = args.join(' ');
  await conn.setStatus(bioBaru);
  m.reply('Bio telah diganti!');
   }
}
