export default {
    before: true,
    exec: async function(m, conn, {cmd}) {
        if (global.error = true) return
        await conn.sendMessage(
    global.option.owner + '@s.whatsapp.net',
    {
        text: 'Halo admin ada eror nih: 

' + global.error
    }
)
    }
}
