export default async function Case(m, conn, command, quoted, msg) {
    switch (command) {
        case 'test': {
            m.reply('ok')
            
            
 //tes
        } break
        case 'kadi' : {
        	m.reply('gacor kang')
        } break
        case 'pagi':
      m.reply('Selamat pagi!')
      break
    case 'siang':
      m.reply('Selamat siang!')
      break
    case 'malam':
      m.reply('Selamat malam!')
      break
      
      
      
//tesss
    case 'info':
      m.reply(`Informasi Bot:\nNama: ${global.option.nameBot}\nVersi: ${global.version}`)
      break
  case 'profil':
  const profileUrl = await conn.profilePictureUrl(m.sender)
  if (profileUrl) {
    await conn.sendMessage(m.chat, {
      image: { url: profileUrl },
      caption: `Nama: ${m.pushName}\nNomor: ${m.sender.split('@')[0]}`
    })
  } else {
    m.reply('Foto profil tidak ditemukan!')
  }
  break
  
  
//tes
  case 'kirim':
  const _text = m.text.slice(6)
  if (!_text) return m.reply('Teks tidak boleh kosong!')
  await conn.sendMessage(m.chat, { 
    text: _text, 
    contextInfo: { 
      externalAdReply: { 
        showAdAttribution: true, 
        title: global.option.nameBot, 
        body: `Bot Created By Rendy`, 
        thumbnailUrl: 'https://iili.io/2ZkYwQf.jpg', 
        sourceUrl: 'https://chat.whatsapp.com/FjowKt0fQTZGx1tRIC5v4s', 
        mediaType: 1, 
        renderLargerThumbnail: true 
      } 
    } 
  })
  m.reply('Pesan berhasil dikirim!')
  break
  
  
  
//donasi
    case 'donasi':
      m.reply(`Donasi untuk bot:\nPulsa: 083818744065\nOVO: 083818744065`)
      break
      
      //kgk jls
      
    }
}